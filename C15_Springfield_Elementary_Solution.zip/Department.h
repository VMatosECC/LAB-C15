#pragma once
#include "Person.h"

//------------------------------------------------------------
// Aggregation class � Department
// Holds references (pointers) to Professor objects it does NOT
// own.  The caller creates and deletes the Professor objects.
//------------------------------------------------------------
class Department {
private:
    string             deptName;
    string             officeNumber;
    vector<Professor*> professors;   // referenced, not owned

public:
    Department(string name, string office)
        : deptName(name), officeNumber(office) {
    }

    void addProfessor(Professor* p) {
        professors.push_back(p);
    }

    string toString() const {
        ostringstream sout;
        sout << this << " --- Department [" << deptName
            << ", Office: " << officeNumber << " ---\n";
        for (const auto& p : professors) {
            sout << p->toString() << endl;
        }
        return sout.str();
    }

    friend ostream& operator<<(ostream& sout, const Department& d) {
        sout << d.toString();
        return sout;
    }

    // No delete in destructor � caller owns the Professor objects
    // ~Department() = default;
    ~Department() {
        cout << "+ Department deleted " << this << " Nothing to delete" << endl;
    }
};
