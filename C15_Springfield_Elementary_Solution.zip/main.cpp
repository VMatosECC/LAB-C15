// C15_Springfield_Elementary.cpp
//============================================================
// C15_Inheritance.h
// Springfield Elementary � Person / Student / Professor /
//                          Employee / Department
//
// Demonstrates: public inheritance, pure virtual toString(),
//   virtual destructors, runtime polymorphism, dynamic_cast,
//   and aggregation (Department references Professor objects).
//
// Author : V. Matos  �  El Camino College
//============================================================

#include <iostream>
#include "Person.h"
#include "Student.h"
#include "Professor.h"
#include "Department.h"
#include "Employee.h"
using namespace std;


void experiment01() {
    cout << "experiment01 " << endl;
    Person* p1 = new Student("Bart Simpson", 10, 2.13);
    Person* p2 = new Professor("Edna Krabapple", 45, 28);

    cout << "*p1 " << p1->toString() << endl; // Calls Student�s display()
    cout << "*p2 " << p2->toString() << endl; // Calls Professor�s display()

    delete p1;
    delete p2;
}
//-------------------------------------------------------------------------

void experiment02() {
    cout << "experiment02 " << endl;
    // Part 3: Runtime Polymorphism
    cout << "=== Part 3: Runtime Polymorphism ===\n";
    Person* p1 = new Student("Bart Simpson", 10, 2.13);
    Person* p2 = new Professor("Edna Krabapple", 45, 28);
    cout << "*p1 " << p1->toString() << endl;
    cout << "*p2 " << p2->toString() << endl;

    delete p1;
    delete p2;

    // Part 4.2: Vector of Person Pointers
    cout << "\n=== Part 4.2: Vector of Person Pointers ===\n";
    vector<Person*> people;
    people.push_back(new Student("Milhouse Van Houten", 10, 2.85));
    people.push_back(new Professor("Elizabeth Hoover", 40, 15));
    people.push_back(new Employee("Groundskeeper Willie", 50, 45000.0));
    for (const auto& person : people) {
        cout << person->toString() << endl;
    }

    // Part 4.3: Testing dynamic_cast
    cout << "\n=== Part 4.3: Testing dynamic_cast ===\n";
    for (auto person : people) {
        if (Employee* emp = dynamic_cast<Employee*>(person)) {
            cout << "Found an Employee object!\n";
            cout << emp->toString() << endl;
        }
    }

    // Part 5: Aggregation with Department
    cout << "\n=== Part 5: Aggregation Experiment ===\n";
    Professor* prof1 = new Professor("Seymour Skinner", 50, 20);
    Professor* prof2 = new Professor("Coach Krup", 42, 12);
    Department generalStudies("General Studies", "Building B, Room 101");
    generalStudies.addProfessor(prof1);
    generalStudies.addProfessor(prof2);
    cout << generalStudies.toString() << endl;;

    // Clean up dynamic memory
    for (auto person : people) {
        delete person;
    }

    delete prof1;
    delete prof2;
}






//--------------------------------------------------------------------
int main() {
    //experiment01();
    experiment02();
    cout << "\nAll done!" << endl;
}



