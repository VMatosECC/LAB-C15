#pragma once
#include "Person.h"

//------------------------------------------------------------
// Derived class � Employee
// Employee IS-A Person with an additional salary field.
//------------------------------------------------------------
class Employee : public Person {
protected:
    double salary;

public:
    Employee(string n = "Unknown", int a = 0, double s = 0.0)
        : Person(n, a), salary(s) {
    }

    string toString() const override {
        ostringstream sout;
        sout << this << " Employee["
            << Person::toString()
            << "   Salary : $" << salary << "]";
        return sout.str();
    }

    virtual ~Employee() {
        cout << "+ Employee destructor called for " << name << "\n";
    }
};
