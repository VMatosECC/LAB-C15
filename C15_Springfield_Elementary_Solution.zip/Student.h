#pragma once
#include "Person.h"
using namespace std;

//------------------------------------------------------------
// Derived class � Student
//------------------------------------------------------------
class Student : public Person {
protected:
    double gpa;

public:
    Student(string n = "Unknown", int a = 0, double g = 0.0)
        : Person(n, a), gpa(g) {
    }

    string toString() const override {
        ostringstream sout;
        sout << this << " Student["
            << Person::toString()        // reuse shared name/age block
            << ", GPA  : " << gpa << "]";
        return sout.str();
    }

    virtual ~Student() {
        cout << "+ Student destructor called for " << name << "\n";
    }
};
