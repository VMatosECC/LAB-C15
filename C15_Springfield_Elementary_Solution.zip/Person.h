#pragma once
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
using namespace std;


#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

//------------------------------------------------------------
// Base class � Person  (abstract)
// toString() is pure virtual � Person cannot be instantiated.
// A body is still defined outside the class so derived classes
// can call Person::toString() to get the shared name/age text.
//------------------------------------------------------------
class Person {
protected:
    string name;
    int    age;

public:
    Person(string n = "Unknown", int a = 0) : name(n), age(a) {}

    // Pure virtual � every derived class MUST override this.
    virtual string toString() const = 0;

    // Virtual destructor � required when deleting derived objects
    // through a Person* pointer.
    virtual ~Person() {
        //message displayed for debugging purposes
        cout << "+ Person destructor called for " << name << "\n";
    }

    // Stream insertion operator � works for ALL derived types
    // because toString() is virtual.
    friend ostream& operator<<(ostream& sout, const Person& p) {
        sout << p.toString();
        return sout;
    }
};

// Body of the pure virtual function (must be outside the class).
// Returns the shared name/age block that every derived class reuses.
string Person::toString() const {
    ostringstream sout;
    sout << this << " Person[Name: " << name 
        << ", Age: " << age << "]";
    return sout.str();
}
