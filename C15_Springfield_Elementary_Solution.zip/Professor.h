#pragma once
#include "Person.h"
using namespace std;

//------------------------------------------------------------
// Derived class � Professor
//------------------------------------------------------------
class Professor : public Person {
protected:
    int yearsExperience;

public:
    Professor(string n = "Unknown", int a = 0, int y = 0)
        : Person(n, a), yearsExperience(y) {
    }

    string toString() const override {
        ostringstream sout;
        sout << this << " Professor[ "
            << Person::toString()
            << ", Experience : " << yearsExperience << "]";
        return sout.str();
    }

    virtual ~Professor() {
        cout << "+ Professor destructor called for " << name << "\n";
    }
};

